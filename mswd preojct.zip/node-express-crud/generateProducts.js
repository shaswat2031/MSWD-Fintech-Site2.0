const mongoose = require('mongoose');
const faker = require('@faker-js/faker').faker;
const Product = require('./models/productModel');

// MongoDB connection
mongoose
  .connect('mongodb://127.0.0.1:27017/productsdb', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => console.log('MongoDB connected'))
  .catch((err) => console.error('Database connection error:', err));

// Generate 50 random products
const generateProducts = () => {
  const products = [];
  for (let i = 0; i < 50; i++) {
    products.push({
      name: faker.commerce.productName(),
      price: parseFloat(faker.commerce.price(10, 500, 2)),
      description: faker.commerce.productDescription(),
      inStock: faker.datatype.boolean(),
    });
  }
  return products;
};

// Insert products into the database
const seedDatabase = async () => {
  try {
    const products = generateProducts();
    await Product.insertMany(products);
    console.log('50 random products added successfully!');
    mongoose.connection.close();
  } catch (error) {
    console.error('Error seeding database:', error);
    mongoose.connection.close();
  }
};

seedDatabase();
